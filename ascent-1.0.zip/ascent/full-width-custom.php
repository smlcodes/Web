<?php
/*
Post Template Name: full-width-custom
*/

get_header(); ?>
<style>
 .entry-content h2 {
    font-family: 'Ubuntu', sans-serif;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	text-align: center;
	background-color: #1ABC9C;
    color: white;
    padding: 10px;
    font-size: 20px;
}


 
</style>

<div class="row">


	
    <div class="col-sm-12 col-md-12">
	<?php while ( have_posts() ) : the_post(); ?>
	    <?php ascent_content_nav( 'nav-below' ); ?>

		<?php get_template_part( 'content', 'single' ); ?>

		<?php ascent_content_nav( 'nav-below' ); ?>

		<?php
			// If comments are open or we have at least one comment, load up the comment template
			if ( comments_open() || '0' != get_comments_number() )
				comments_template();
		?>

	<?php endwhile; // end of the loop. ?>

    </div>
    
 
</div>
<?php get_footer(); ?>
