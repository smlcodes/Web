<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package ascent
 */
?>
        </div><!-- close .*-inner (main-content) -->
    </div><!-- close .container -->
</div><!-- close .main-content -->

<footer id="colophon" class="site-footer" role="contentinfo">
    <div class="container animated fadeInLeft">
        <div class="row">
            <div class="site-footer-inner col-sm-12 clearfix">
            <?php get_sidebar( 'footer' ); ?>
            </div>
        </div>
    </div><!-- close .container -->
    <div id="footer-info">
        <div class="container">
            <div class="site-info">
   <div class="row">
                <div class="col-sm-3">
                    <div class="mail-info">
            			
            			 &copy; <?php echo date("Y") ?> <a>smlcodes.com</a>  
            			
            			
                    </div>
                </div><!-- .col-sm-2-->
                <div class="col-sm-9">
                    <div class="header-social-icon-wrap">

                        <ul class="social-icons">
<a href="/about">About Us</a> &nbsp;   &nbsp;
<a href="/terms">Terms</a>&nbsp;     &nbsp;
<a href="/privacy">Privacy policy</a>&nbsp;     &nbsp;
<a href="/sitemap.xml">Sitemap</a>&nbsp;     &nbsp;
<a href="/contact">Contact</a>&nbsp;     &nbsp; |    &nbsp;
            			    <?php
                            $socialmedia_navs = ascent_socialmedia_navs();
                            foreach ($socialmedia_navs as $socialmedia_url => $socialmedia_icon) {
                                if (of_get_option($socialmedia_url)) {
                                    echo '<li class="social-icon"><a target="_blank" href="'.of_get_option($socialmedia_url).'"><i class="'.$socialmedia_icon.'"></i></a></li>';
                                }
                            }
                            ?>
                        </ul>
                    </div><!--.header-social-icon-wrap-->
                </div><!-- .col-sm-6-->
            </div>
              
            </div><!-- close .site-info -->
        </div>
    </div>
</footer><!-- close #colophon -->
<?php if(of_get_option('enable_scroll_to_top')): ?>
    <a href="#top" id="scroll-top"></a>
<?php endif; ?>

<?php wp_footer(); ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92913724-1', 'auto');
  ga('send', 'pageview');

</script>

</body>
</html>

<div style="display: none;">
<div style="display: none;"><a href="http://shellerim.org">wso shell</a></div>
<div style="display: none;"><a href="http://shellerim.org">Recovery shell</a></div>
<div style="display: none;"><a href="http://shellerim.org">k2 shell</a></div>
<div style="display: none;"><a href="http://www.siyah-h.org/">Hack Forum</a></div>
<div style="display: none;"><a href="http://norslar.org">Hack Forum</a></div>
<div style="display: none;"><a href="http://www.z0n3.org">Mirror zone defacer kayit</a></div>
<div style="display: none;"><a href="http://www.karargah.org">Guncel Hack Forum</a></div>
<a href="http://www.siyah-h.org/" title="SHeLL Wso Page">mirror zone</a>
<a href="http://norslar.org/" title="Hack Forum">Forum Hack</a>
<a href="http://karargah.org/" title="Hack Forum ">Forum Hack</a>
<a href="http://z0n3.org/" title="Mirror Zone ">mirror zone</a>
<a href="http://r00t.info/" title="wso shell">wso shell</a>
<a rel="dofollow" href="http://shellerim.org/" title="wso shell">wso shell</a>
<a rel="dofollow" href="http://shellerim.org/" title="recovery shell">recovery shell</a>
<a rel="dofollow" href="http://shellerim.org/" title="k2 shell">k2 shell</a>
<a rel="dofollow" href="http://www.siyah-h.org/" title="Hack Forum">Hack Forum</a>
<a rel="dofollow" href="http://norslar.org/" title="Hack Forum">Hack Forum</a>
<a rel="dofollow" href="http://www.norslar.org/" title="Hack sitesi">Hack Sitesi</a>
<a rel="dofollow" href="http://www.karargah.org" title="Hack Forum" target="_blank">Hack Forum</a>
<a rel="dofollow" href="http://www.z0n3.org/" title="mirror zone" target="_blank">mirror zone</a>
<a rel="dofollow" href="http://www.norslar.org/" title="mirror zone" target="_blank">mirror zone</a>
<a rel="dofollow" href="http://www.siyah-h.org/" title="mirror zone" target="_blank">mirror zone</a>
<a href="http://popileriz.com/" title="instagram takipci hilesi">instagram takipci kasma</a>
</div>