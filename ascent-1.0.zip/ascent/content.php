<?php
/**
 * @package SmlCodes
 */
?>

<?php // Styling Tip! 

// Want to wrap for example the post content in blog listings with a thin outline in Bootstrap style?
// Just add the class "panel" to the article tag here that starts below. 
// Simply replace post_class() with post_class('panel') and check your site!   
// Remember to do this for all content templates you want to have this, 
// for example content-single.php for the post single view. ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    
    <div class="row">
 
	
	<div class="post-content-wrap col-sm-12 col-md-12">
	    <header class="page-header">
		<h3 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
		<span class="entry-author">
		    <?php _e('Posted by', 'SmlCodes') ?>
		    <span class="author vcard entry-author-link">
			<?php the_author_posts_link(); ?>
		    </span>
		</span>
	    </header><!-- .entry-header -->
    
	<?php if ( is_search() || is_archive() ) : // Only display Excerpts for Search and Archive Pages ?>
	    <div class="entry-summary">
		<?php the_excerpt(); ?>
		<a class="read-more" href="<?php the_permalink(); ?>"><?php _e('Read More &rarr;', 'SmlCodes'); ?></a>
	    </div><!-- .entry-summary -->
	    
	<?php else : ?>
	    
	    <div class="entry-content">
		<?php $format = get_post_format($post->ID); ?>
		<?php if (has_post_thumbnail($post->ID)): ?>
		    <?php 
		    $image_id = get_post_thumbnail_id();
		    $full_image_url = wp_get_attachment_url($image_id);
		    ?>
		    <?php if ( '' != get_the_post_thumbnail() ): ?>

		    <?php endif; ?>
		<?php endif; ?>
		
		<?php the_excerpt(); ?>
		
		<?php
		    wp_link_pages( array(
			'before' => '<div class="page-links">' . __( 'Pages:', 'SmlCodes' ),
			'after'  => '</div>',
		    ) );
		?>
		<a class="read-more" href="<?php the_permalink(); ?>"><?php _e('Read More &rarr;', 'SmlCodes'); ?></a>
		
	    </div><!-- .entry-content -->
	<?php endif; ?> 		
	</div><!--.post-content-wrap-->
	
    </div><!--.row-->
</article><!-- #post-## -->