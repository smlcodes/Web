<?php
/**
 * The Template for displaying all single posts.
 *
 * @package ascent
 */

get_header(); ?>
<style>
 .entry-content h2 {
    font-family: 'Ubuntu', sans-serif;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	text-align: center;
	background-color: #1ABC9C;
    color: white;
    padding: 10px;
    font-size: 20px;
}


.tuto-bar {
    margin-top: 1px;
	margin-bottom : 1px;
    min-height: inherit;
    background-color: #1ABC9C;	   
	text-align: center;
    width: 100%;
    position: relative;     
    min-height: 32px;    
	color: #fff;
	box-shadow: 0 0 5px -1px rgba(0,0,0,0.2);
    cursor:pointer;   
	height: 32px;
	line-height: 32px;  
	display:none;	
}



@media screen and (min-width: 0px) and (max-width: 760px) {
  #showBtn {  
  display: block;
  }
  #tutorial_side_bar {  
  display:none;
  }
 #closeBtn {  
  display:none;
  }
}

@media screen and (min-width: 760px) {
  #showBtn {  
  display:none;
  }
   #closeBtn {  
  display:none;
  }
 
  #tutorial_side_bar {  
 display: block;
  }

}
 
</style>

<div class="row">

<div id="showBtn" class="tuto-bar" onclick="showmethod()"><b><i class="fa fa-bars"></i> Show Topics</b></div>
<div id="closeBtn" class="tuto-bar" onclick="hidemethod()"><b><i class="fa fa-times"></i> Hide Topics</b></div>
    <div class="col-sm-12 col-md-3" id="tutorial_side_bar">		
        <?php get_sidebar(); ?>
    </div>
	
    <div class="col-sm-12 col-md-9">
	<?php while ( have_posts() ) : the_post(); ?>
	    <?php ascent_content_nav( 'nav-below' ); ?>

		<?php get_template_part( 'content', 'single' ); ?>

		<?php ascent_content_nav( 'nav-below' ); ?>

		<?php
			// If comments are open or we have at least one comment, load up the comment template
			if ( comments_open() || '0' != get_comments_number() )
				comments_template();
		?>

	<?php endwhile; // end of the loop. ?>

    </div>
    
 
</div>
<?php get_footer(); ?>

<script>
jQuery(document).ready(function($){	
var url=$(location).attr('href').split( '/' );
$l1 =  url[ url.length - 2 ];

 $('.nav li a').each(function() {
	 	 
	 var linkurl=$(this).prop('href').split( '/' );	
	 $l2 =  linkurl[ linkurl.length - 2 ];
	 
	 
    if ($l1 == $l2) {			
      //$('.nav li a').addClass('on');	  
	 $(this).css({
    "background-color": "#1ABC9C",
    "color": "#ffffff"
});
	 
    }else {
            
        }
  });
});

 function showmethod() {
    var shw = document.getElementById('showBtn');
	var cls = document.getElementById('closeBtn');
	var tut = document.getElementById('tutorial_side_bar');	
         shw.style.display = 'none';
		 cls.style.display = 'block';
		 tut.style.display = 'block';
    }  
	
	 function hidemethod() {
    var shw = document.getElementById('showBtn');
	var cls = document.getElementById('closeBtn');
	var tut = document.getElementById('tutorial_side_bar');	
         shw.style.display = 'block';
		 cls.style.display = 'none';
		 tut.style.display = 'none';
    } 

</script>
