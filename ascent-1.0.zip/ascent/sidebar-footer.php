<?php
/**
 * The sidebar containing the main widget area
 *
 * @package ascent
 */
?>
  

    <?php // add the class "panel" below here to wrap the sidebar in Bootstrap style ;) ?>
    <div class="sidebar-padder">

      <?php do_action( 'before_sidebar' ); ?>
      <?php if ( ! dynamic_sidebar( 'sidebar-footer' ) ) : ?>
  
       
  
  
      <?php endif; ?>
      
    </div><!-- close .sidebar-padder -->
